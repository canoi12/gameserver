#include <iostream>
#include <string>
#include <boost/asio.hpp>

int main() {
	unsigned short port = 3333;
	std::string address = "127.0.0.1";
}